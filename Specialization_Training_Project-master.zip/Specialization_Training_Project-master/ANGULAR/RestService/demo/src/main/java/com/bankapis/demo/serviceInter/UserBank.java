package com.bankapis.demo.serviceInter;

import java.util.List;

public interface UserBank {

    List<UserBank> listAllBanks();
}
